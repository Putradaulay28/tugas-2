<br> <br> <br> <br>  
<!DOCTYPE html>
<html>
<head>
	<title>404 Not Found</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="background-color: #eeeeee;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">404 Not Found</div>
					<div class="panel-body">
						<h3>Maaf Halaman Tidak Ada :(</h3>
						<h4><a class="btn btn-warning" href="pln">PLN</a> | <a class="btn btn-primary" href="agen">AGEN</a></h4>
					</div>
					<div class="panel-footer">
						<center>&copy;2018 - Muhammad Ramdan | Distributed by <a href="https://blogbugabagi.blogspot.com" target="_blank" rel="noopener noreferrer">BlogBugaBagi</a></center>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>