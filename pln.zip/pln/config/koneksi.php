<?php  
	mysqli_connect("localhost","root","");
	mysql_select_db("zidun");

?>
$con = $sql_details;